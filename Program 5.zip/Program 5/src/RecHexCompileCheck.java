public class RecHexCompileCheck
{

	private static void testRect() {
		Rectangle t = new Rectangle(10, 10, 10, 10, "red");
		t.setColor("blue");
		t.setHeight(20);
		t.setWidth(20);
		t.setXPosition(20);
		t.setYPosition(20);
		String s = t.getColor();
		int i = t.getHeight();
		i = t.getWidth();
		i = t.getXPosition();
		i = t.getYPosition();
		Point[] ps = t.getVertices();
		boolean b = t.equals(t);
		b = t.isInsideBox(400, 400);
		Rectangle r2 = new Rectangle(t);
	}

	private static void testHexagon() {
		Hexagon h = new Hexagon(10, 10, 10, 10, "red");
		h.setColor("blue");
		h.setHeight(20);
		h.setWidth(20);
		h.setXPosition(20);
		h.setYPosition(20);
		String s = h.getColor();
		int i = h.getHeight();
		i = h.getWidth();
		i = h.getXPosition();
		i = h.getYPosition();
		Point[] ps = h.getVertices();
		boolean b = h.equals(h);
		b = h.isInsideBox(400, 400);
		Hexagon h2 = new Hexagon(h);
	}

	public static void main(String[] args) {

	}

}
